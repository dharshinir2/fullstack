import { Loader } from "rsuite"

const Spinner=()=>{
    return(

        <div><Loader/></div>
        
    )
}
export default Spinner