import CustomNavbar from "../components/customnavbar"

const EditBooking=()=>{
    return(
        <div>
            <header>

            <CustomNavbar/>
            </header>
            <main>
                <section>
                    <p>This is edit page raa</p>

                </section>
            </main>

        </div>
    )
}
export default EditBooking